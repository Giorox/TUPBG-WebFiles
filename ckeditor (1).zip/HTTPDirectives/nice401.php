<?php $results['pageTitle'] = "Página Não Autorizada | Tenda Pai Benedito";
include "../templates/include/header.php" ?>

<ul id="headlines">
	<br>
	<br>
    <div class="card mb-4">
        <div class="card-body">
            <h2 class="card-title" align="middle">Oops, algo deu errado!</h2>
            <p class="card-text" align="middle">
				<img src="images/logotipo_pai_benedito.jpg" height="250" width="500"></img>
				<p><b>Infelizmente você não possui acesso a esta página, mas não desanime, há muito o que ler por aqui! (Erro 401)</b></p>
			</p>
        </div>
    </div>
</ul>

<?php include "../templates/include/footer.php" ?>