<?php $results['pageTitle'] = "Obá | Tenda de Umbanda Pai Benedito da Guiné";
include "templates/include/header.php" ?>

    <ul class="col-sm-12" id="headlines">
		<!-- Blog Post -->
		<br>
		<br>
        <div class="card mb-4">
			<div class="card-body">
			<img class="card-img-top" src="images/oba.jpg" alt="Card image cap">
				<h2 class="card-title"><center>OBÁ</center></h2>
					<p class="card-text">
						<p style="margin-left:0cm; margin-right:0cm; text-align:justify"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Ob&aacute; &eacute; um Orix&aacute; que possui um car&aacute;ter apaixonado e corajoso. N&atilde;o teme nada nem ningu&eacute;m. Considerada senhora da guerra, uma amazona destemida, e uma s&aacute;bia e justa feiticeira. Como n&atilde;o conhece o medo, n&atilde;o existem inc&ocirc;modos que a desviem de seus objetivos. &Eacute; pr&aacute;tica, poderosa, leal e sempre muito correta. </span></span></span></span></span></p>

<p style="margin-left:0cm; margin-right:0cm; text-align:justify"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Todos aqueles que possuem demandas judiciais e necessitam apelar para inst&acirc;ncias maiores, dever&aacute; pedir a Ob&aacute;. Mas lembre-se, ela s&oacute; ajuda os injusti&ccedil;ados. </span></span></span></span></span></p>

<p style="margin-left:0cm; margin-right:0cm; text-align:justify"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Ajuda a encontrar objetos perdidos e toma sob sua prote&ccedil;&atilde;o todas as mulheres que possuem casamentos infelizes ou que foram tra&iacute;das pelo marido. Mentiras atraem a sua ira. </span></span></span></span></span></p>

<p style="margin-left:0cm; margin-right:0cm; text-align:justify"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">O dom&iacute;nio de Ob&aacute; s&atilde;o as corredeiras, as &aacute;guas revoltas. </span></span></span></span></span></p>

<p style="margin-left:0cm; margin-right:0cm; text-align:justify"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Ob&aacute; &eacute; uma feiticeira velha e muito poderosa, l&iacute;der da confraria das mulheres guerreiras. &Eacute; uma iab&aacute; das &aacute;guas, mas domina todos os elementos. Por sua tenacidade, &eacute; muito solicitada em causas imposs&iacute;veis. </span></span></span></span></span></p>

<p style="margin-left:0cm; margin-right:0cm; text-align:justify"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&Eacute; retratada ora como uma mulher idosa e ranzinza, ora como uma guerreira em traje de montaria, sempre com sua espada e seu escudo inteiramente entregue &agrave; batalha. Ob&aacute; n&atilde;o possui vaidade, n&atilde;o liga para a pr&oacute;pria apar&ecirc;ncia. &Eacute; muito dotada fisicamente, sua for&ccedil;a pode ser maior que a dos outros Orix&aacute;s masculinos, mas beleza certamente n&atilde;o um de seus atributos. </span></span></span></span></span></p>

<p style="margin-left:0cm; margin-right:0cm; text-align:justify"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Representa as emo&ccedil;&otilde;es reprimidas e insatisfeitas, o sofrimento que d&aacute; a sensibilidade para sintonizar-se com as v&iacute;timas da injusti&ccedil;a. &Eacute; amarga pelo desprezo do marido, despreza a juventude. </span></span></span></span></span></p>

<p style="margin-left:0cm; margin-right:0cm; text-align:justify"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Introspectiva, gosta de solid&atilde;o, n&atilde;o &eacute; soci&aacute;vel e fala pouco. Generosa, mas n&atilde;o gosta de brincadeiras, n&atilde;o aceita pedido de desculpas. </span></span></span></span></span></p>

<p style="margin-left:0cm; margin-right:0cm; text-align:justify"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">As caracter&iacute;sticas de Ob&aacute; foram absorvidas por Nan&atilde; e Ians&atilde; na maioria das doutrinas de Umbanda. </span></span></span></span></span></p>

<ul>
	<li style="text-align:justify"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><strong><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Outros Detalhes</span></span></strong></span></span></span></li>
	<li style="margin-left: 0cm; margin-right: 0cm; text-align: justify;"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Sincretismo: Santa Joana D&rsquo;Arc;</span></span></span></span></span></li>
	<li style="margin-left: 0cm; margin-right: 0cm; text-align: justify;"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Data de culto: 30 de maio;</span></span></span></span></span></li>
	<li style="margin-left: 0cm; margin-right: 0cm; text-align: justify;"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Sauda&ccedil;&atilde;o: Ob&aacute; Xir&ecirc;</span></span></span></span></span></li>
	<li style="margin-left: 0cm; margin-right: 0cm; text-align: justify;"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&Aacute;rea de atua&ccedil;&atilde;o:;</span></span></span></span></span></li>
	<li style="margin-left: 0cm; margin-right: 0cm; text-align: justify;"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Elemento: Terra e Vegetal; </span></span></span></span></span></li>
	<li style="margin-left: 0cm; margin-right: 0cm; text-align: justify;"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Chacra: - ; </span></span></span></span></span></li>
	<li style="margin-left: 0cm; margin-right: 0cm; text-align: justify;"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Metal: - ; </span></span></span></span></span></li>
	<li style="margin-left: 0cm; margin-right: 0cm; text-align: justify;"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Astro regente: - ; </span></span></span></span></span></li>
	<li style="margin-left: 0cm; margin-right: 0cm; text-align: justify;"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Dia da semana: - ; </span></span></span></span></span></li>
	<li style="margin-left: 0cm; margin-right: 0cm; text-align: justify;"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Cor da guia: Vermelhas e brancas, &agrave;s vezes verde; </span></span></span></span></span></li>
	<li style="margin-left: 0cm; margin-right: 0cm; text-align: justify;"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Cor da vela: magenta, marrom, vermellho;</span></span></span></span></span></li>
	<li style="margin-left: 0cm; margin-right: 0cm; text-align: justify;"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Pedra: Turmalina verde, jaspe madeira, madeira fossilizada;</span></span></span></span></span></li>
	<li style="margin-left: 0cm; margin-right: 0cm; text-align: justify;"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Bebida: Vinho tinto licoroso, &aacute;gua com hortel&atilde; e mel; </span></span></span></span></span></li>
	<li style="margin-left: 0cm; margin-right: 0cm; text-align: justify;"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Amal&aacute;: - ; </span></span></span></span></span></li>
	<li style="margin-left: 0cm; margin-right: 0cm; text-align: justify;"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Frutas: abacaxi, uva rosa, ameixa preta; </span></span></span></span></span></li>
	<li style="margin-left: 0cm; margin-right: 0cm; text-align: justify;"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Flores: Peregum roxo, rosas brancas, amor perfeito e flores dos campo; </span></span></span></span></span></li>
	<li style="margin-left: 0cm; margin-right: 0cm; text-align: justify;"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Algumas ervas: ra&iacute;zes em geral, dand&aacute; da costa; </span></span></span></span></span></li>
	<li style="margin-left: 0cm; margin-right: 0cm; text-align: justify;"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Local de oferta: Pr&oacute;ximos &agrave;s matas; </span></span></span></span></span></li>
	<li style="margin-left: 0cm; margin-right: 0cm;"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:14.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Instrumentos: Espada, escudo e arco e flecha(Of&aacute;);</span></span></span></span></span></li>
</ul>
<p style="margin-left:0cm; margin-right:0cm; text-align:justify"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:10.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Fontes: </span></span></span></span></span></p>

<li style="margin-left:0cm; margin-right:0cm; text-align:justify"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:10.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Marcio Kain, Curso de Teologia da Umbanda;</span></span></span></span></span></li>

<li style="margin-left:0cm; margin-right:0cm; text-align:justify"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:10.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Fl&aacute;vio Penteado, Povo de Aruanda;</span></span></span></span></span></li>

<li style="margin-left:0cm; margin-right:0cm; text-align:justify"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:10.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Ademir Jr, Teologia de Umbanda e suas dimens&otilde;es;</span></span></span></span></span></li>

<li style="margin-left:0cm; margin-right:0cm; text-align:justify"><span style="font-size:12pt"><span style="font-family:Calibri,sans-serif"><span style="color:black"><span style="font-size:10.0pt"><span style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Lurdes Vieira, Manual Doutrin&aacute;rio, Ritualistico e Comportamental Umbandista</span></span></span></span></span></li>

					</p>
					<a href="AUmbanda_OSORIXAS.php" class="btn btn-primary">&larr; Retornar aos Orixás</a>
            </div>
            <div class="card-footer text-muted">
				Atualizado pela última vez em 13/04/2019
				<br>
            </div>
        </div>
    </ul>

<?php include "templates/include/footer.php" ?>